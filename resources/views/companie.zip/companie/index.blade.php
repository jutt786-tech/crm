@extends('layouts.app')

@section('content')
<div class="container">
    
    <div class="row">
        <div class="col-md-12">
           <hr>
           <a href="{{asset('companie/create')}}" class="btn btn-info" >ADD companies</a>
        <hr>
        <div class="row">
          <div class="col-md-8 col-md-offset-2">

              @if(count($errors) > 0)
             <ul>
                 @foreach($errors->all() as $error)
                     <li class="alert alert-info">{{$error}}</li>
                 @endforeach
             </ul>
           @endif
         </div>

            <table id="dtBasicExample" class="table table-striped table-bordered table-sm" cellspacing="0" width="100%">
              <thead>
                <tr>
                  <th class="th-sm">Id</th>
                  <th class="th-sm">Name</th>
                  <th class="th-sm">Email</th>
                  <th class="th-sm">logo</th>
                  <th class="th-sm">website</th>
                  <th class="th-sm">Edit</th>
                  <th class="th-sm">Delete</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>1</td>
                  <td>Tiger Nixon</td>
                  <td>System Architect</td>
                  <td>Edinburgh</td>
                  <td>61</td>
                  <td><a href="#" class="btn btn-primary">edite</a></td>
                  <td><a href="#" class="btn btn-danger">Delted</a></td>
                </tr>
               
              </tbody>
              <tfoot>
               <tr>
                  <th class="th-sm">Id</th>
                  <th class="th-sm">Name</th>
                  <th class="th-sm">Email</th>
                  <th class="th-sm">logo</th>
                  <th class="th-sm">website</th>
                  <th class="th-sm">Edit</th>
                  <th class="th-sm">Delete</th>
                </tr>
              </tfoot>
            </table>
        </div>
    </div>


</div>
@endsection
